import React from 'react';
import { View, Text, Button } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Contact from '../components/Contact';

const HomeScreen = () => {
  const navigation = useNavigation();

  return (
    <View>
      <View>
        <Contact 
          gambar={require("../assets/zee.jpg")}
          judul={
            <View style={{ backgroundColor: '#96C9F4', padding: 7, borderRadius: 10  }}>
              <Text>Azizi shafa asadel</Text>
            </View>
          }
          onPress={() => navigation.navigate('ContactDetail', {
            gambar: require("../assets/zee.jpg"),
            judul: "Zee",
            telpon: "0765535531",
            deskripsi: "she is my idol"
          })}
        />
      </View>
      <View>
        <Contact 
          gambar={require("../assets/ale.jpg")}
          judul={
            <View style={{ backgroundColor: '#96C9F4', padding: 7, borderRadius: 10 }}>
              <Text>Aliah Desilpa</Text>
            </View>
          }
          onPress={() => navigation.navigate('ContactDetail', {
            gambar: require("../assets/ale.jpg"),
            judul: "Ale",
            telpon: "080808080808",
            deskripsi: "she is my GF"
          })}
        />
      </View>
      <View>
        <Contact 
          gambar={require("../assets/bul.jpg")}
          judul={
            <View style={{ backgroundColor: '#96C9F4', padding: 5, borderRadius: 10 }}>
              <Text>Lingkay</Text>
            </View>
          }
          onPress={() => navigation.navigate('ContactDetail', {
            gambar: require("../assets/bul.jpg"),
            judul: "Kabul",
            telpon: "classified",
            deskripsi: "he's my homie"
          })}
        />
      </View>
      <View>
        <Contact 
          gambar={require("../assets/el.jpg")}
          judul={
            <View style={{ backgroundColor: '#96C9F4', padding: 7, borderRadius: 10 }}>
              <Text>Azazel</Text>
            </View>
          }
          onPress={() => navigation.navigate('ContactDetail', {
            gambar: require("../assets/el.jpg"),
            judul: "Kevin",
            telpon: "privacy",
            deskripsi: "This is me"
          })}
        />
      </View>
    </View>
  );
};

export default HomeScreen;