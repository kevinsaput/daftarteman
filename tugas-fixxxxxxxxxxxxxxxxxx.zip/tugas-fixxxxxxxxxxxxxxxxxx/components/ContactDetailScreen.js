import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';

const ContactDetailScreen = ({ route }) => {
  const { gambar, judul, telpon, deskripsi } = route.params;

  return (
    <View style={styles.container}>
      <Image source={gambar} style={styles.image} />
      <Text style={styles.judul}>{judul}</Text>
      <Text style={styles.telpon}>Number: {telpon}</Text>
      <Text style={styles.deskripsi}>Desc: {deskripsi}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  image: {
    width: 150,
    height: 150,
    borderRadius: 75,
    marginBottom: 20,
  },
  judul: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  telpon: {
    fontSize: 18,
    color: '#666',
  },
});

export default ContactDetailScreen;