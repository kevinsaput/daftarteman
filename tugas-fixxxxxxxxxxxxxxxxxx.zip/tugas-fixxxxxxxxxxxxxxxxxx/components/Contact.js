import React from 'react';
import { View, Text, Image, TouchableOpacity } from 'react-native';

const Contact = ({ gambar, judul, telpon, onPress }) => {
  return (
    <TouchableOpacity onPress={onPress}>
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <Image source={gambar} style={{ width: 50, height: 50, borderRadius: 50, marginRight: 10, marginBottom: 20 }} />
        <View style={{ width: 150, height:50, borderRadius:50, marginRight:10 }}>
          <Text>{judul}</Text>
          <Text>{telpon}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );
};

export default Contact;